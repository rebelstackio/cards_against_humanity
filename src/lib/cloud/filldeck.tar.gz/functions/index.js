const functions = require('firebase-functions');
let admin = require("firebase-admin");
const https = require('https');
let serviceAccount = require("./serviceAccountKey.json");
const { createRoom } = require('./room');

admin.initializeApp({
	credential: admin.credential.cert(serviceAccount),
	databaseURL: "https://cardsagainsthumanity-fcd9e.firebaseio.com"
});
let _DB = admin.firestore();

/* -----------------------ROOM ------------------------ */
exports.createRoom = functions.https.onCall((data, context) => {
	createRoom(data,context,_DB);
});

exports.getDeck = functions.https.onCall((name) => {
	console.log(name);
	getBaseDeck('Base', (data) => {
		console.log(data)
		writeDeck(data, 'Base');
	});
	return true
});

function writeDeck(data, dName) {
	const ref = _DB.collection('decks').doc(dName)//.document(`/decks/${dName}`) //_DB.ref(`/decks/${dName}`);
	ref.set(data)
}
/**
 * SOON TO BE DEPRECATED
 */
function getBaseDeck(name, callback) {
	const url = 'https://cards-against-humanity-api.herokuapp.com/sets/' + name;
	let data = '';
	https.get(url, (resp) => {
		console.log(resp.statusCode)
		resp.on('data', (chunk) => {
			data += chunk
		});
		resp.on('end', () => {
			callback(JSON.parse(data))
		})
	})
}
