(() => {
	function createRoom(param, context, _DB) {
		const {uid} = context.auth;
		const ref = _DB.collection('rooms').collection(uid);
		return ref.once('value', (snap) => {
			console.log(snap.val)
			return { uid, snap: snap.val }
		})
		//console.log(param, context.auth.uid);
	}

	module.exports = { createRoom }
})()
